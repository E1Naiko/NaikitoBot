"""Fachada del módulo SeptSinFP.

Los cogs importan desde acá y no directamente de ``database`` ni ``logic``,
igual que en los módulos Madrugue y Box.
"""

from datetime import date

from modules.ssf.constants import (
    TEXTO_AYUDA,
)

from modules.ssf.database import (
    crear_desafio,
    eliminar_participante,
    eliminar_registro,
    guardar_registro,
    obtener_desafio_activo,
    obtener_estadisticas_desafio,
    obtener_participante,
    obtener_participantes,
    obtener_registros_usuario,
    obtener_ultimo_desafio,
    registrar_participante,
    tiene_registro,
    actualizar_participante,
    reactivar_participante,
    obtener_ultima_revision_ssf,
    guardar_ultima_revision_ssf,
    obtener_ranking_final,
    marcar_desafio_cerrado,
)

from modules.ssf.logic import (
    calcular_mejor_racha,
    calcular_racha,
    calcular_rango,
    fecha_dentro_del_desafio,
)

from core.database import conectar_db


__all__ = [
    # Constantes
    "TEXTO_AYUDA",
    # Lógica pura
    "calcular_mejor_racha",
    "calcular_racha",
    "calcular_rango",
    "fecha_dentro_del_desafio",
    # Desafíos y participantes
    "agregar_dia",
    "cerrar_desafio_activo",
    "cerrar_desafios_finalizados",
    "eliminar_faltantes",
    "eliminar_participante_admin",
    "iniciar_desafio",
    "quitar_dia",
    "recalcular_rachas",
    "obtener_desafio_para_ranking",
    "obtener_estado_desafio",
    "obtener_estado_usuario",
    "obtener_lista_participantes",
    "procesar_eliminaciones_diarias",
    "registrar_sobrevivi",
    "registrar_usuario",
    "revivir_participante",
]


def iniciar_desafio(
    guild_id,
    nombre,
    fecha_inicio,
    fecha_fin,
    canal_id,
):
    """
    Crea un nuevo desafío.

    No permite crear otro desafío activo en el mismo servidor.
    """

    existente = obtener_desafio_activo(
        guild_id
    )

    if existente:
        return {
            "exitoso": False,
            "motivo": "ya_existe",
        }

    desafio_id = crear_desafio(
        guild_id=guild_id,
        nombre=nombre,
        fecha_inicio=fecha_inicio,
        fecha_fin=fecha_fin,
        canal_id=canal_id,
    )

    return {
        "exitoso": True,
        "desafio_id": desafio_id,
    }


def registrar_usuario(
    guild_id,
    user_id,
    username,
    ahora,
):
    """
    Registra un usuario en el desafío activo.
    """

    desafio = obtener_desafio_activo(
        guild_id
    )

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    (
        desafio_id,
        _guild_id,
        nombre,
        fecha_inicio,
        fecha_fin,
        canal_id,
        _activo,
    ) = desafio

    fecha = ahora.date()

    if not fecha_dentro_del_desafio(
        fecha,
        fecha_inicio,
        fecha_fin,
    ):
        return {
            "exitoso": False,
            "motivo": "fuera_de_fecha",
            "nombre": nombre,
        }

    participante = obtener_participante(
        desafio_id,
        user_id,
    )

    if participante is not None:

        if participante[4]:
            return {
                "exitoso": False,
                "motivo": "eliminado",
            }

        return {
            "exitoso": False,
            "motivo": "ya_registrado",
        }

    registrar_participante(
        desafio_id=desafio_id,
        user_id=user_id,
        username=username,
        fecha_registro=ahora.isoformat(),
    )

    # Registrarse cuenta como haber sobrevivido el día. Sin esto, quien se
    # registra el 1/9 y cumple del 2 al 6 quedaba con racha 5 en lugar de 6,
    # porque sólo /ssf sobrevivi creaba entradas en ssf_registros.
    guardar_registro(
        desafio_id=desafio_id,
        user_id=user_id,
        fecha=fecha.isoformat(),
        hora=ahora.strftime("%H:%M:%S"),
    )

    fechas = [
        date.fromisoformat(
            registro[0]
        )
        for registro in obtener_registros_usuario(
            desafio_id,
            user_id,
        )
    ]

    racha = calcular_racha(
        fechas,
        fecha,
    )

    mejor_racha = calcular_mejor_racha(
        fechas
    )

    actualizar_participante(
        desafio_id=desafio_id,
        user_id=user_id,
        racha_actual=racha,
        mejor_racha=mejor_racha,
    )

    return {
        "exitoso": True,
        "motivo": "registrado",
        "nombre": nombre,
        "fecha_inicio": fecha_inicio,
        "fecha_fin": fecha_fin,
        "racha": racha,
        "mejor_racha": mejor_racha,
        "rango": calcular_rango(racha),
    }


def registrar_sobrevivi(
    guild_id,
    user_id,
    ahora,
):
    """
    Registra la supervivencia diaria de un participante.
    """

    desafio = obtener_desafio_activo(
        guild_id
    )

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    (
        desafio_id,
        _guild_id,
        nombre,
        fecha_inicio,
        fecha_fin,
        canal_id,
        _activo,
    ) = desafio

    fecha = ahora.date()

    if not fecha_dentro_del_desafio(
        fecha,
        fecha_inicio,
        fecha_fin,
    ):
        return {
            "exitoso": False,
            "motivo": "fuera_de_fecha",
        }

    participante = obtener_participante(
        desafio_id,
        user_id,
    )

    if participante is None:
        return {
            "exitoso": False,
            "motivo": "no_participante",
        }

    if participante[4]:
        return {
            "exitoso": False,
            "motivo": "eliminado",
        }

    if tiene_registro(
        desafio_id,
        user_id,
        fecha.isoformat(),
    ):
        return {
            "exitoso": False,
            "motivo": "ya_registrado",
        }

    guardar_registro(
        desafio_id=desafio_id,
        user_id=user_id,
        fecha=fecha.isoformat(),
        hora=ahora.strftime("%H:%M:%S"),
    )

    registros = obtener_registros_usuario(
        desafio_id,
        user_id,
    )

    fechas = [
        date.fromisoformat(
            registro[0]
        )
        for registro in registros
    ]

    racha = calcular_racha(
        fechas,
        fecha,
    )

    mejor_racha = calcular_mejor_racha(
        fechas
    )

    actualizar_participante(
        desafio_id=desafio_id,
        user_id=user_id,
        racha_actual=racha,
        mejor_racha=mejor_racha,
    )

    return {
        "exitoso": True,
        "motivo": "sobrevivio",
        "nombre": nombre,
        "racha": racha,
        "mejor_racha": mejor_racha,
        "rango": calcular_rango(racha),
        "fecha": fecha,
        "hora": ahora,
    }


def obtener_estado_usuario(
    guild_id,
    user_id,
):
    """Obtiene el estado actual de un participante."""

    desafio = obtener_desafio_activo(
        guild_id
    )

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    participante = obtener_participante(
        desafio[0],
        user_id,
    )

    if participante is None:
        return {
            "exitoso": False,
            "motivo": "no_participante",
        }

    return {
        "exitoso": True,
        "nombre": desafio[2],
        "eliminado": bool(participante[4]),
        "fecha_eliminacion": participante[5],
        "racha_actual": participante[6],
        "mejor_racha": participante[7],
        "rango": calcular_rango(participante[6]),
    }


def eliminar_faltantes(
    guild_id,
    fecha,
):
    """
    Elimina a todos los participantes activos que no
    registraron /SSF sobrevivi durante la fecha indicada.
    """

    desafio = obtener_desafio_activo(
        guild_id
    )

    if desafio is None:
        return 0

    desafio_id = desafio[0]

    participantes = obtener_participantes(
        desafio_id
    )

    eliminados = 0

    for participante in participantes:

        user_id = participante[0]
        eliminado = participante[3]

        if eliminado:
            continue

        if not tiene_registro(
            desafio_id,
            user_id,
            fecha.isoformat(),
        ):
            eliminar_participante(
                desafio_id=desafio_id,
                user_id=user_id,
                fecha_eliminacion=fecha.isoformat(),
            )

            eliminados += 1

    return eliminados


def obtener_estado_desafio(
    guild_id,
):
    """Obtiene las estadísticas del desafío activo."""

    desafio = obtener_desafio_activo(
        guild_id
    )

    if desafio is None:
        return None

    total, activos, eliminados = (
        obtener_estadisticas_desafio(
            desafio[0]
        )
    )

    return {
        "id": desafio[0],
        "nombre": desafio[2],
        "fecha_inicio": desafio[3],
        "fecha_fin": desafio[4],
        "canal_id": desafio[5],
        "total": total,
        "activos": activos,
        "eliminados": eliminados,
    }


def obtener_lista_participantes(
    guild_id,
):
    """Obtiene los participantes del desafío activo."""

    desafio = obtener_desafio_activo(
        guild_id
    )

    if desafio is None:
        return None

    return obtener_participantes(
        desafio[0]
    )

def revivir_participante(
    guild_id,
    user_id,
    fecha,
):
    """
    Revive a un participante eliminado y registra
    retroactivamente el día que había perdido.

    La operación está pensada para corregir olvidos,
    problemas de conexión u otros inconvenientes.

    La fecha indicada debe ser un día dentro del desafío.
    """

    desafio = obtener_desafio_activo(guild_id)

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    (
        desafio_id,
        _guild_id,
        nombre,
        fecha_inicio,
        fecha_fin,
        canal_id,
        _activo,
    ) = desafio

    if not fecha_dentro_del_desafio(
        fecha,
        fecha_inicio,
        fecha_fin,
    ):
        return {
            "exitoso": False,
            "motivo": "fuera_de_fecha",
        }

    participante = obtener_participante(
        desafio_id,
        user_id,
    )

    if participante is None:
        return {
            "exitoso": False,
            "motivo": "no_participante",
        }

    if not participante[4]:
        return {
            "exitoso": False,
            "motivo": "no_eliminado",
        }

    if tiene_registro(
        desafio_id,
        user_id,
        fecha.isoformat(),
    ):
        return {
            "exitoso": False,
            "motivo": "ya_registrado",
        }

    # Registrar retroactivamente el día perdido.
    guardar_registro(
        desafio_id=desafio_id,
        user_id=user_id,
        fecha=fecha.isoformat(),
        hora="ADMIN",
    )

    # Recuperar todas las fechas después del registro.
    registros = obtener_registros_usuario(
        desafio_id,
        user_id,
    )

    fechas = [
        date.fromisoformat(
            registro[0]
        )
        for registro in registros
    ]

    racha = calcular_racha(
        fechas,
        fecha,
    )

    mejor_racha = calcular_mejor_racha(
        fechas,
    )

    # El participante vuelve a estar activo.
    actualizar_participante(
        desafio_id=desafio_id,
        user_id=user_id,
        racha_actual=racha,
        mejor_racha=mejor_racha,
    )

    # Quitar estado de eliminado.
    reactivar_participante(
        desafio_id=desafio_id,
        user_id=user_id,
    )

    return {
        "exitoso": True,
        "motivo": "revivido",
        "nombre": nombre,
        "racha": racha,
        "mejor_racha": mejor_racha,
        "rango": calcular_rango(racha),
        "fecha": fecha,
    }

# ============================================================
# REPARACIÓN MANUAL (SOLO ADMINISTRADORES)
# ============================================================

def _actualizar_rachas_desde_registros(
    desafio_id,
    user_id,
):
    """
    Recalcula ambas rachas desde los registros guardados.

    Los registros son la fuente de verdad y las rachas
    almacenadas un caché: la racha actual es la racha
    consecutiva que termina en el último día registrado.

    No toca el estado de eliminado del participante.
    """

    registros = obtener_registros_usuario(
        desafio_id,
        user_id,
    )

    fechas = [
        date.fromisoformat(
            registro[0]
        )
        for registro in registros
    ]

    if not fechas:
        racha = 0
    else:
        racha = calcular_racha(
            fechas,
            max(fechas),
        )

    mejor_racha = calcular_mejor_racha(
        fechas
    )

    actualizar_participante(
        desafio_id=desafio_id,
        user_id=user_id,
        racha_actual=racha,
        mejor_racha=mejor_racha,
    )

    return (
        racha,
        mejor_racha,
    )


def agregar_dia(
    guild_id,
    user_id,
    fecha,
    hoy,
):
    """
    Agrega manualmente un día sobrevivido a un participante activo.

    Sirve para corregir olvidos o errores sin revivir a nadie:
    el participante debe estar activo (para eliminados existe
    ``revivir_participante``). No acepta fechas futuras.
    """

    desafio = obtener_desafio_activo(guild_id)

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    (
        desafio_id,
        _guild_id,
        nombre,
        fecha_inicio,
        fecha_fin,
        _canal_id,
        _activo,
    ) = desafio

    if not fecha_dentro_del_desafio(
        fecha,
        fecha_inicio,
        fecha_fin,
    ):
        return {
            "exitoso": False,
            "motivo": "fuera_de_fecha",
        }

    participante = obtener_participante(
        desafio_id,
        user_id,
    )

    if participante is None:
        return {
            "exitoso": False,
            "motivo": "no_participante",
        }

    if participante[4]:
        return {
            "exitoso": False,
            "motivo": "eliminado",
        }

    if fecha > hoy:
        return {
            "exitoso": False,
            "motivo": "futura",
        }

    if tiene_registro(
        desafio_id,
        user_id,
        fecha.isoformat(),
    ):
        return {
            "exitoso": False,
            "motivo": "ya_registrado",
        }

    guardar_registro(
        desafio_id=desafio_id,
        user_id=user_id,
        fecha=fecha.isoformat(),
        hora="ADMIN",
    )

    racha, mejor_racha = (
        _actualizar_rachas_desde_registros(
            desafio_id,
            user_id,
        )
    )

    return {
        "exitoso": True,
        "motivo": "agregado",
        "nombre": nombre,
        "racha": racha,
        "mejor_racha": mejor_racha,
        "rango": calcular_rango(racha),
        "fecha": fecha,
    }


def quitar_dia(
    guild_id,
    user_id,
    fecha,
):
    """
    Quita manualmente un día sobrevivido a un participante.

    Acepta participantes eliminados: quitar un día no cambia
    el estado de eliminado, solo recalcula las rachas desde
    los registros restantes.

    No valida que la fecha esté dentro del desafío ni que no
    sea futura: si existe un registro erróneo, hay que poder
    borrarlo sea cual sea su fecha.
    """

    desafio = obtener_desafio_activo(guild_id)

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    desafio_id = desafio[0]
    nombre = desafio[2]

    participante = obtener_participante(
        desafio_id,
        user_id,
    )

    if participante is None:
        return {
            "exitoso": False,
            "motivo": "no_participante",
        }

    if not tiene_registro(
        desafio_id,
        user_id,
        fecha.isoformat(),
    ):
        return {
            "exitoso": False,
            "motivo": "sin_registro",
        }

    eliminar_registro(
        desafio_id=desafio_id,
        user_id=user_id,
        fecha=fecha.isoformat(),
    )

    racha, mejor_racha = (
        _actualizar_rachas_desde_registros(
            desafio_id,
            user_id,
        )
    )

    return {
        "exitoso": True,
        "motivo": "quitado",
        "nombre": nombre,
        "racha": racha,
        "mejor_racha": mejor_racha,
        "rango": calcular_rango(racha),
        "fecha": fecha,
        "eliminado": bool(participante[4]),
    }


def recalcular_rachas(
    guild_id,
    user_id,
):
    """
    Recalcula las rachas de un participante desde sus registros.

    No cambia el estado de eliminado: sirve para reparar la
    racha mostrada cuando quedó en un valor incorrecto (por
    ejemplo, participantes eliminados por el código anterior
    a la corrección, que pisaba la racha con 0).
    """

    desafio = obtener_desafio_activo(guild_id)

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    desafio_id = desafio[0]
    nombre = desafio[2]

    participante = obtener_participante(
        desafio_id,
        user_id,
    )

    if participante is None:
        return {
            "exitoso": False,
            "motivo": "no_participante",
        }

    racha, mejor_racha = (
        _actualizar_rachas_desde_registros(
            desafio_id,
            user_id,
        )
    )

    return {
        "exitoso": True,
        "motivo": "recalculado",
        "nombre": nombre,
        "racha": racha,
        "mejor_racha": mejor_racha,
        "rango": calcular_rango(racha),
        "eliminado": bool(participante[4]),
    }

# ============================================================
# ELIMINACIÓN AUTOMÁTICA
# ============================================================

def procesar_eliminaciones_diarias(fecha):
    """
    Procesa la eliminación automática de todos los desafíos
    SSF activos.

    Cada desafío se procesa de manera independiente.
    """

    resultados = []

    with conectar_db() as db:

        desafios = db.execute("""
            SELECT
                id,
                guild_id,
                nombre,
                fecha_inicio,
                fecha_fin,
                canal_id,
                activo
            FROM ssf_desafios
            WHERE activo = 1
        """).fetchall()

    for desafio in desafios:

        (
            desafio_id,
            guild_id,
            nombre,
            fecha_inicio,
            fecha_fin,
            canal_id,
            activo,
        ) = desafio

        # ----------------------------------------------------
        # COMPROBAR QUE LA FECHA PERTENECE AL DESAFÍO
        # ----------------------------------------------------

        if not fecha_dentro_del_desafio(
            fecha,
            fecha_inicio,
            fecha_fin,
        ):
            continue

        # ----------------------------------------------------
        # EVITAR PROCESAR DOS VECES LA MISMA FECHA
        # ----------------------------------------------------

        ultima_revision = (
            obtener_ultima_revision_ssf(
                desafio_id
            )
        )

        if ultima_revision is not None:

            ultima_revision_obj = date.fromisoformat(
                ultima_revision
            )

            if fecha <= ultima_revision_obj:
                continue

        # ----------------------------------------------------
        # OBTENER PARTICIPANTES
        # ----------------------------------------------------

        participantes = obtener_participantes(
            desafio_id
        )

        eliminados = []

        for participante in participantes:

            (
                user_id,
                username,
                _fecha_registro,
                eliminado,
                _fecha_eliminacion,
                _racha_actual,
                _mejor_racha,
            ) = participante

            # Ya eliminado → no tocar.
            if eliminado:
                continue

            # Tiene supervivencia → continúa.
            if tiene_registro(
                desafio_id,
                user_id,
                fecha.isoformat(),
            ):
                continue

            # No registró → eliminar.
            eliminar_participante(
                desafio_id=desafio_id,
                user_id=user_id,
                fecha_eliminacion=fecha.isoformat(),
            )

            eliminados.append({
                "user_id": user_id,
                "username": username,
            })

        # ----------------------------------------------------
        # GUARDAR FECHA PROCESADA
        # ----------------------------------------------------

        guardar_ultima_revision_ssf(
            desafio_id=desafio_id,
            fecha=fecha.isoformat(),
        )

        resultados.append({
            "desafio_id": desafio_id,
            "guild_id": guild_id,
            "nombre": nombre,
            "canal_id": canal_id,
            "fecha": fecha,
            "eliminados": eliminados,
        })

    return resultados

# ============================================================
# CIERRE AUTOMÁTICO
# ============================================================

def cerrar_desafios_finalizados(fecha):
    """
    Cierra automáticamente los desafíos cuya fecha de fin
    ya fue procesada.

    Devuelve la información necesaria para publicar
    el resultado final.
    """

    resultados = []

    with conectar_db() as db:

        desafios = db.execute("""
            SELECT
                id,
                guild_id,
                nombre,
                fecha_inicio,
                fecha_fin,
                canal_id,
                activo
            FROM ssf_desafios
            WHERE activo = 1
        """).fetchall()

    for desafio in desafios:

        (
            desafio_id,
            guild_id,
            nombre,
            fecha_inicio,
            fecha_fin,
            canal_id,
            activo,
        ) = desafio

        fecha_fin_obj = date.fromisoformat(
            fecha_fin
        )

        # ----------------------------------------------------
        # TODAVÍA NO TERMINÓ
        # ----------------------------------------------------

        if fecha <= fecha_fin_obj:
            continue

        # ----------------------------------------------------
        # EL ÚLTIMO DÍA TIENE QUE HABER SIDO PROCESADO
        # ----------------------------------------------------

        ultima_revision = (
            obtener_ultima_revision_ssf(
                desafio_id
            )
        )

        if ultima_revision is None:
            continue

        ultima_revision_obj = date.fromisoformat(
            ultima_revision
        )

        if ultima_revision_obj < fecha_fin_obj:
            continue

        # ----------------------------------------------------
        # OBTENER RANKING FINAL
        # ----------------------------------------------------

        ranking = obtener_ranking_final(
            desafio_id
        )

        total = len(ranking)

        sobrevivientes = [
            participante
            for participante in ranking
            if not participante[2]
        ]

        eliminados = [
            participante
            for participante in ranking
            if participante[2]
        ]

        # ----------------------------------------------------
        # CERRAR DESAFÍO
        # ----------------------------------------------------

        cerrado = marcar_desafio_cerrado(
            desafio_id
        )

        if cerrado == 0:
            continue

        # ----------------------------------------------------
        # GUARDAR RESULTADO
        # ----------------------------------------------------

        resultados.append({
            "desafio_id": desafio_id,
            "guild_id": guild_id,
            "nombre": nombre,
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
            "canal_id": canal_id,
            "total": total,
            "sobrevivientes": sobrevivientes,
            "eliminados": eliminados,
            "ranking": ranking,
        })

    return resultados

# ============================================================
# ADMINISTRACIÓN MANUAL (SOLO ADMINISTRADORES)
# ============================================================

def eliminar_participante_admin(
    guild_id,
    user_id,
    fecha,
    hoy,
):
    """Elimina manualmente a un participante que faltó un día.

    Es la reparación simétrica de ``revivir_participante``: replica lo que
    habría hecho el proceso automático diario si se hubiera ejecutado.
    """

    desafio = obtener_desafio_activo(guild_id)

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    (
        desafio_id,
        _guild_id,
        nombre,
        fecha_inicio,
        fecha_fin,
        canal_id,
        _activo,
    ) = desafio

    if not fecha_dentro_del_desafio(
        fecha,
        fecha_inicio,
        fecha_fin,
    ):
        return {
            "exitoso": False,
            "motivo": "fuera_de_fecha",
        }

    if fecha > hoy:
        return {
            "exitoso": False,
            "motivo": "futura",
        }

    participante = obtener_participante(
        desafio_id,
        user_id,
    )

    if participante is None:
        return {
            "exitoso": False,
            "motivo": "no_participante",
        }

    if participante[4]:
        return {
            "exitoso": False,
            "motivo": "ya_eliminado",
        }

    if tiene_registro(
        desafio_id,
        user_id,
        fecha.isoformat(),
    ):
        return {
            "exitoso": False,
            "motivo": "con_registro",
        }

    eliminar_participante(
        desafio_id=desafio_id,
        user_id=user_id,
        fecha_eliminacion=fecha.isoformat(),
    )

    return {
        "exitoso": True,
        "nombre": nombre,
        "fecha": fecha.isoformat(),
        "racha_actual": participante[6],
        "mejor_racha": participante[7],
    }


def cerrar_desafio_activo(guild_id):
    """Cierra el desafío activo y devuelve su resultado final."""

    desafio = obtener_desafio_activo(guild_id)

    if desafio is None:
        return {
            "exitoso": False,
            "motivo": "sin_desafio",
        }

    (
        desafio_id,
        _guild_id,
        nombre,
        fecha_inicio,
        fecha_fin,
        canal_id,
        _activo,
    ) = desafio

    ranking = obtener_ranking_final(desafio_id)

    marcar_desafio_cerrado(desafio_id)

    sobrevivientes = [
        fila
        for fila in ranking
        if not fila[2]
    ]

    eliminados = [
        fila
        for fila in ranking
        if fila[2]
    ]

    return {
        "exitoso": True,
        "desafio_id": desafio_id,
        "nombre": nombre,
        "fecha_inicio": fecha_inicio,
        "fecha_fin": fecha_fin,
        "canal_id": canal_id,
        "total": len(ranking),
        "sobrevivientes": sobrevivientes,
        "eliminados": eliminados,
        "ranking": ranking,
    }


def obtener_desafio_para_ranking(guild_id):
    """Devuelve el desafío a rankear: el activo o el más reciente."""

    desafio = obtener_desafio_activo(guild_id)

    activo = True

    if desafio is None:
        desafio = obtener_ultimo_desafio(guild_id)
        activo = False

    if desafio is None:
        return None

    (
        desafio_id,
        _guild_id,
        nombre,
        fecha_inicio,
        fecha_fin,
        canal_id,
        _activo_db,
    ) = desafio

    return {
        "desafio_id": desafio_id,
        "nombre": nombre,
        "fecha_inicio": fecha_inicio,
        "fecha_fin": fecha_fin,
        "canal_id": canal_id,
        "activo": activo,
        "ranking": obtener_ranking_final(desafio_id),
    }
